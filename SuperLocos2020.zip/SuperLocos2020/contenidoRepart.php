<?php

session_start();

echo "Hola " . $_SESSION['usuario'];

?>